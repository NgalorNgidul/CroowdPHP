<?php sleep(1);?>
<div class="media other-post-item">
	<a href="#" class="thumb-left">
		<img src="images/ex/th-90x90-3.jpg" alt="$TITLE">
	</a>
	<div class="media-body">
		<h4 class="rs title-other-post">
			<a href="#" class="be-fc-orange fw-b">Maecenas interdum ipsum</a>
		</h4>
		<p class="rs fc-gray time-post pb10">posted 4 days ago</p>
		<p class="rs description">Nam nec sem ac risus congue varius. Maecenas interdum ipsum tempor ipsum fringilla eu vehicula urna vehicula.</p>
	</div>
</div><!--end: . other-post-item -->
<div class="media other-post-item">
	<a href="#" class="thumb-left">
		<img src="images/ex/th-90x90-4.jpg" alt="$TITLE">
	</a>
	<div class="media-body">
		<h4 class="rs title-other-post">
			<a href="#" class="be-fc-orange fw-b">Nam nec sem ac risus</a>
		</h4>
		<p class="rs fc-gray time-post pb10">posted 5 days ago</p>
		<p class="rs description">Nam nec sem ac risus congue varius. Maecenas interdum ipsum tempor ipsum fringilla eu vehicula urna vehicula.</p>
	</div>
</div><!--end: . other-post-item -->
<div class="media other-post-item">
	<a href="#" class="thumb-left">
		<img src="images/ex/th-90x90-1.jpg" alt="$TITLE">
	</a>
	<div class="media-body">
		<h4 class="rs title-other-post">
			<a href="#" class="be-fc-orange fw-b">Lorem ipsum dolor</a>
		</h4>
		<p class="rs fc-gray time-post pb10">posted 6 days ago</p>
		<p class="rs description">Nam nec sem ac risus congue varius. Maecenas interdum ipsum tempor ipsum fringilla eu vehicula urna vehicula.</p>
	</div>
</div><!--end: .other-post-item -->