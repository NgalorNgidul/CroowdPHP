<div class="row-item clearfix">
    <label class="lbl" for="txt_name1">Team Profile*</label>
    <div class="val">
        <input class="txt" type="text" id="txt_teamProfile" placeholder="Team Profile" value="">
    </div>
</div>
<div class="row-item clearfix">
    <label class="lbl" for="txt_name1">Profile Summary*</label>
    <div class="val">
        <input class="txt" type="text" id="txt_profileSummary" placeholder="Profile Summary" value="">
    </div>
</div>
<div class="row-item clearfix">
    <label class="lbl" for="txt_name1">Company Website*</label>
    <div class="val">
        <input class="txt" type="text" id="txt_website" placeholder="Company Website" value="">
    </div>
</div>
<div class="row-item clearfix">
    <label class="lbl" for="txt_name1">Skype Id*</label>
    <div class="val">
        <input class="txt" type="text" id="txt_skype" placeholder="Skype Id" value="">
    </div>
</div>
<div class="row-item clearfix">
    <label class="lbl" for="txt_name1">Facebook Fan Page*</label>
    <div class="val">
        <input class="txt" type="text" id="txt_teamProfile" placeholder="Facebook Fan Page" value="">
    </div>
</div>
<div class="row-item clearfix">
    <label class="lbl" for="txt_name1">Creators Blog*</label>
    <div class="val">
        <input class="txt" type="text" id="txt_blog" placeholder="Creators Blog" value="">
    </div>
</div>
<div class="row-item clearfix">
    <label class="lbl" for="txt_name1">Other Social Link*</label>
    <div class="val">
        <input class="txt" type="text" id="txt_social1" placeholder="Other Social Link" value="">
    </div>
</div>
<div class="row-item clearfix">
    <label class="lbl" for="txt_name1">Other Social Link*</label>
    <div class="val">
        <input class="txt" type="text" id="txt_social2" placeholder="Other Social Link" value="">
    </div>
</div>
<div class="row-item clearfix">
    <label class="lbl" for="txt_name1">Other Social Link*</label>
    <div class="val">
        <input class="txt" type="text" id="txt_social3" placeholder="Other Social Link" value="">
    </div>
</div>