<!--<ul class="rs nav nav-category">
                            <li>
                                <a href="#">
                                    Art
                                    <span class="count-val">(12)</span>
                                    <i class="icon iPlugGray"></i>
                                </a>
                            </li>
                            <li class="active">
                                <a href="#">
                                    Comics
                                    <span class="count-val">(12)</span>
                                    <i class="icon iPlugGray"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Design
                                    <span class="count-val">(12)</span>
                                    <i class="icon iPlugGray"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Fashion
                                    <span class="count-val">(12)</span>
                                    <i class="icon iPlugGray"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Film
                                    <span class="count-val">(12)</span>
                                    <i class="icon iPlugGray"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Games
                                    <span class="count-val">(12)</span>
                                    <i class="icon iPlugGray"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Music
                                    <span class="count-val">(12)</span>
                                    <i class="icon iPlugGray"></i>
                                </a>
                            </li>
                        </ul>
-->
<ul class="rs nav nav-category">
                    <li>
                        <a href="#">
                            Art
                            <span class="count-val">(12)</span>
                            <i class="icon iPlugGray"></i>
                        </a>
                    </li>
                    <li class="active">
                        <a href="#">
                            Comics
                            <span class="count-val">(12)</span>
                            <i class="icon iPlugGray"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            Design
                            <span class="count-val">(12)</span>
                            <i class="icon iPlugGray"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            Fashion
                            <span class="count-val">(12)</span>
                            <i class="icon iPlugGray"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            Film
                            <span class="count-val">(12)</span>
                            <i class="icon iPlugGray"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            Games
                            <span class="count-val">(12)</span>
                            <i class="icon iPlugGray"></i>
                        </a>
                        <ul class="rs nav-sub-category">
                            <li>
                                <a href="#">
                                    Comedy
                                    <span class="count-val">(12)</span>
                                    <i class="dotSquare"></i>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Animation
                                    <span class="count-val">(12)</span>
                                    <i class="dotSquare"></i>
                                </a>
                            </li>
                        </ul><!--end: .nav-sub-category-->
                    </li>
                    <li>
                        <a href="#">
                            Music
                            <span class="count-val">(12)</span>
                            <i class="icon iPlugGray"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            Photography
                            <span class="count-val">(35)</span>
                            <i class="icon iPlugGray"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            Publishing
                            <span class="count-val">(92)</span>
                            <i class="icon iPlugGray"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            Technology
                            <span class="count-val">(13)</span>
                            <i class="icon iPlugGray"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            Theater
                            <span class="count-val">(29)</span>
                            <i class="icon iPlugGray"></i>
                        </a>
                    </li>
                </ul>