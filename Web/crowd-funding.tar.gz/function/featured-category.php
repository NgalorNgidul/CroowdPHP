<ul class="rs nav nav-category">
                    <li>
                        <a href="#">
                            Staff Picks
                            <span class="count-val">(12)</span>
                            <i class="icon iPlugGray"></i>
                        </a>
                    </li>
                    <li class="active">
                        <a href="#">
                            Popular
                            <span class="count-val">(2)</span>
                            <i class="icon iPlugGray"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            Now Launched
                            <span class="count-val">(212)</span>
                            <i class="icon iPlugGray"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            Ending Soon
                            <span class="count-val">(35)</span>
                            <i class="icon iPlugGray"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            Small Project
                            <span class="count-val">(67)</span>
                            <i class="icon iPlugGray"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            Most Funded
                            <span class="count-val">(23)</span>
                            <i class="icon iPlugGray"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            Curated Pages
                            <span class="count-val">(52)</span>
                            <i class="icon iPlugGray"></i>
                        </a>
                    </li>
                </ul>