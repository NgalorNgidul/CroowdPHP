<select id="location_id" name="data[Project][location_id]" class="txt"  >


    <option value="167" >Singapore</option>
    <option value="86" >Indonesia</option>
    <option value="187" >Thailand</option>
    <option value="113" >Malaysia</option>
    <option value="147" >Philippines</option>
    <option value="207" >Vietnam</option>
    <optgroup label="----------"></optgroup>




    <option value="1">Afghanistan</option>





    <option value="2">Albania</option>





    <option value="3">Algeria</option>





    <option value="4">Andorra</option>





    <option value="5">Angola</option>





    <option value="6">Anguilla</option>





    <option value="7">Antigua and Barbuda</option>





    <option value="8">Argentina</option>





    <option value="9">Armenia</option>





    <option value="10">Aruba</option>





    <option value="11">Australia</option>





    <option value="12">Austria</option>





    <option value="13">Azerbaijan</option>





    <option value="14">Bahamas</option>





    <option value="15">Bahrain</option>





    <option value="16">Bangladesh</option>





    <option value="17">Barbados</option>





    <option value="18">Belarus</option>





    <option value="19">Belgium</option>





    <option value="20">Belize</option>





    <option value="21">Benin</option>





    <option value="22">Bermuda</option>





    <option value="23">Bhutan</option>





    <option value="24">Bolivia</option>





    <option value="25">Bosnia and Herzegovina</option>





    <option value="26">Botswana</option>





    <option value="27">Brazil</option>





    <option value="28">British Virgin islands</option>





    <option value="29">Brunei Darussalam</option>





    <option value="30">Bulgaria</option>





    <option value="31">Burkina Faso</option>





    <option value="32">Burundi</option>





    <option value="33">Cambodia</option>





    <option value="34">Cameroon</option>





    <option value="35">Canada</option>





    <option value="36">Cape Verde</option>





    <option value="37">Cayman Islands</option>





    <option value="38">Central African Republic</option>





    <option value="39">Chad</option>





    <option value="40">Chile</option>





    <option value="41">China, People&#39;s Republic of</option>





    <option value="42">Colombia</option>





    <option value="43">Comoros</option>





    <option value="44">Cook Islands</option>





    <option value="45">Costa Rica</option>





    <option value="46">C&ocirc;te d&#39;Ivoire</option>





    <option value="47">Croatia</option>





    <option value="48">Cuba</option>





    <option value="49">Cyprus</option>





    <option value="50">Czech Republic</option>





    <option value="51">Democratic Republic of Congo</option>





    <option value="52">Denmark</option>





    <option value="53">Djibouti</option>





    <option value="54">Dominica</option>





    <option value="55">Dominican Republic</option>





    <option value="56">Ecuador</option>





    <option value="57">Egypt</option>





    <option value="58">El Salvador</option>





    <option value="59">Equatorial Guinea</option>





    <option value="60">Eritrea</option>





    <option value="61">Estonia</option>





    <option value="62">Ethiopia</option>





    <option value="63">Fiji</option>





    <option value="64">Finland</option>





    <option value="65">France</option>





    <option value="66">Gabon</option>





    <option value="67">Gambia</option>





    <option value="68">Georgia</option>





    <option value="69">Germany</option>





    <option value="70">Ghana</option>





    <option value="71">Gibraltar</option>





    <option value="72">Greece</option>





    <option value="73">Greenland</option>





    <option value="74">Grenada</option>





    <option value="75">Guam</option>





    <option value="76">Guatemala</option>





    <option value="77">Guinea</option>





    <option value="78">Guinea Bissau</option>





    <option value="79">Guyana</option>





    <option value="80">Haiti</option>





    <option value="81">Honduras</option>





    <option value="82">Hong Kong</option>





    <option value="83">Hungary</option>





    <option value="84">Iceland</option>





    <option value="85">India</option>







    <option value="87">Iran</option>





    <option value="88">Iraq</option>





    <option value="89">Ireland</option>





    <option value="90">Israel</option>





    <option value="91">Italy</option>





    <option value="92">Jamaica</option>





    <option value="93">Japan</option>





    <option value="94">Jordan</option>





    <option value="95">Kazakhstan</option>





    <option value="96">Kenya</option>





    <option value="97">Kiribati</option>





    <option value="98">Kuwait</option>





    <option value="99">Kyrgyzstan</option>





    <option value="100">Lao People&#39;s Democratic Republic</option>





    <option value="101">Latvia</option>





    <option value="102">Lebanon</option>





    <option value="103">Lesotho</option>





    <option value="104">Liberia</option>





    <option value="105">Libya</option>





    <option value="106">Liechtenstein</option>





    <option value="107">Lithuania</option>





    <option value="108">Luxembourg</option>





    <option value="109">Macau</option>





    <option value="110">Macedonia</option>





    <option value="111">Madagascar</option>





    <option value="112">Malawi</option>







    <option value="114">Maldives</option>





    <option value="115">Mali</option>





    <option value="116">Malta</option>





    <option value="117">Marshall Islands</option>





    <option value="118">Mauritania</option>





    <option value="119">Mauritius</option>





    <option value="120">Mexico</option>





    <option value="121">Micronesia</option>





    <option value="122">Moldova</option>





    <option value="123">Moldova</option>





    <option value="124">Monaco</option>





    <option value="125">Mongolia</option>





    <option value="126">Montenegro</option>





    <option value="127">Morocco</option>





    <option value="128">Mozambique</option>





    <option value="129">Myanmar</option>





    <option value="130">Namibia</option>





    <option value="131">Nauru</option>





    <option value="132">Nepal</option>





    <option value="133">Netherlands</option>





    <option value="134">New Caledonia</option>





    <option value="135">New Zealand</option>





    <option value="136">Nicaragua</option>





    <option value="137">Niger</option>





    <option value="138">Nigeria</option>





    <option value="139">Norway</option>





    <option value="140">Oman</option>





    <option value="141">Pakistan</option>





    <option value="142">Palau</option>





    <option value="143">Panama</option>





    <option value="144">Papua New Guinea</option>





    <option value="145">Paraguay</option>





    <option value="146">Peru</option>







    <option value="148">Poland</option>





    <option value="149">Portugal</option>





    <option value="150">Puerto Rico</option>





    <option value="151">Qatar</option>





    <option value="152">Republic of the Congo</option>





    <option value="153">Romania</option>





    <option value="154">Russia</option>





    <option value="155">Rwanda</option>





    <option value="156">Saint Kitts and Nevis</option>





    <option value="157">Saint Lucia</option>





    <option value="158">Saint Vincent and the Grenadines</option>





    <option value="159">Samoa</option>





    <option value="160">San Marino</option>





    <option value="161">Sao Tome and Principe</option>





    <option value="162">Saudi Arabia</option>





    <option value="163">Senegal</option>





    <option value="164">Serbia</option>





    <option value="165">Seychelles</option>





    <option value="166">Sierra Leone</option>







    <option value="168">Slovakia</option>





    <option value="169">Slovenia</option>





    <option value="170">Solomon Islands</option>





    <option value="171">Somalia</option>





    <option value="172">South Africa</option>





    <option value="173">South Korea</option>





    <option value="175">South Sudan</option>





    <option value="176">Spain</option>





    <option value="177">Sri Lanka</option>





    <option value="178">Sudan</option>





    <option value="179">Suriname</option>





    <option value="180">Swaziland</option>





    <option value="181">Sweden</option>





    <option value="182">Switzerland</option>





    <option value="183">Syria</option>





    <option value="184">Taiwan</option>





    <option value="185">Tajikistan</option>





    <option value="186">Tanzania</option>







    <option value="188">Timor-Leste</option>





    <option value="189">Togo</option>





    <option value="190">Tokelau</option>





    <option value="191">Tonga</option>





    <option value="192">Trinidad and Tobago</option>





    <option value="193">Tunisia</option>





    <option value="194">Turkey</option>





    <option value="195">Turkmenistan</option>





    <option value="196">Tuvalu</option>





    <option value="197">U.S. Virgin Islands</option>





    <option value="198">Uganda</option>





    <option value="199">Ukraine</option>





    <option value="200">United Arab Emirates</option>





    <option value="201">United Kingdom of Great Britain and Northern Ireland</option>





    <option value="202">United States of America</option>





    <option value="203">Uruguay</option>





    <option value="204">Uzbekistan</option>





    <option value="205">Vanuatu</option>





    <option value="206">Venezuela</option>







    <option value="208">Yemen</option>





    <option value="209">Zambia</option>





    <option value="210">Zimbabwe</option>





    <option value="300">Global</option>



</select>