<div class="md-object rs" data-x="260" data-y="470" data-width="180"
     data-height="23" data-padding-top="9" data-padding-bottom="14"
     data-padding-left="10" data-padding-right="10" data-start="0"
     data-stop="0" data-easein="random" data-easeout="keep">
    <!--<a href="#" class="btn btn-gray">Learn more</a> -->
    <button type="submit" class="btn btn-blue" style="width: 200px;height: 60px;font-size: 18px;">Cari Pinjaman</button>

</div>
<div class="md-object rs" data-x="500" data-y="470" data-width="180"
     data-height="23" data-padding-top="9" data-padding-bottom="14"
     data-padding-left="10" data-padding-right="10" data-start="0"
     data-stop="0" data-easein="random" data-easeout="keep" >
    <!--<a href="#" class="btn btn-gray">Learn more</a> -->
    <button type="submit" class="btn btn-blue" style="width: 240px;height: 60px;font-size: 18px;">Lend Your Money</button>

</div>