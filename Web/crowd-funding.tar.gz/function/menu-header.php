<ul id="main-menu" class="nav nav-horizontal clearfix">
    <li class="active"><a href="index.php">Home</a></li>
    <li class="sep"></li>
    <li><a href="#allpages"  onclick="onMenu('allpages')" id="allpages">All Pages</a></li>
    <li class="sep"></li>
    <li><a href="#help" onclick="onMenu('help')" id="help">Help</a></li>
    <li class="sep"></li>
    <li><a href="#contact" onclick="onMenu('contact')" id="contact">Contact</a></li>
</ul>
<a id="btn-toogle-menu" class="btn-toogle-menu" href="#alternate-menu">
    <span class="line-bar"></span>
    <span class="line-bar"></span>
    <span class="line-bar"></span>
</a>
<div id="right-menu">
    <ul class="alternate-menu">
        <li><a href="index.php">Home</a></li>
        <li><a href="#allpages" id="allpages" onclick="onMenu('allpages')">All Pages</a></li>
        <li><a href="#help" id="help" onclick="onMenu('help')" >Help</a></li>
        <li><a href="#contact" id="contact" onclick="onMenu('contact')" >Contact us</a></li>
    </ul>
</div>