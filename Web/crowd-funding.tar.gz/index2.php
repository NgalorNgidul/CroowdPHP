<?php

include 'component/'.$_GET['content'].'/'.$_GET['content'].'.php';


?>

